﻿using System;
using System.Collections;

public class Program
{
    static public void Main()
    {
        Queue line = new Queue();

        line.Enqueue("Nick");
        line.Enqueue("Taylor");
        line.Enqueue("Lexi");
        line.Enqueue("Peter");
        line.Enqueue("Mike");
        line.Enqueue("Daniel");

        int customers = line.Count;

        for (int i = 0; i < customers; i++)
        {
            Console.WriteLine("{0} is being served.", line.Peek());
            Console.WriteLine("Pouring {0}\'s drink...", line.Peek());
            Console.WriteLine("Scooping {0}\'s popcorn...", line.Peek());
            Console.WriteLine("Grabbing {0}\'s candy...", line.Peek());
            Console.WriteLine("{0} is good to go!", line.Peek());
            line.Dequeue();
        }
    }
}